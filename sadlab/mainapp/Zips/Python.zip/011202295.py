# Get input from the user
num1 = float(input())
num2 = float(inut())
num3 = float(input())
# Calculate the sum
sum_of_numbers = num1 + num2 + num3

# Display the result
print(sum_of_numbers)
