for i in range(2):
    print("hello")

i=0
n=5
while(i<n):
    i+=1

print(i)